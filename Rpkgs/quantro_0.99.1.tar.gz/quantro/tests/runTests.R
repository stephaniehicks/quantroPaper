require("quantro") || stop("unable to load quantro")
BiocGenerics:::testPackage("quantro")