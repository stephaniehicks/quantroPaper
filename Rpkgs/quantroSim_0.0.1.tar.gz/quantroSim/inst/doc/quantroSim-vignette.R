## ----style-knitr, eval=TRUE, echo=FALSE, results="asis"---------------------------------
    BiocStyle::latex()

## ----install-lib, eval=FALSE, echo=TRUE-------------------------------------------------
#  library(devtools)
#  install_github(repo = "quantroSim", username = "stephaniehicks")

## ----lib-load, message=FALSE------------------------------------------------------------
library(quantroSim)

## ----methTruth-Fig, fig.width=10, fig.height=5------------------------------------------
set.seed(999)
methTruth <- simulateMethTruth(nProbes = 2e4, nGroups = 2, 
                               pDiff = 0.05, pUp = 0.80)
plotMethTruth(methTruth)

## ----methTruth-summary------------------------------------------------------------------
dim(methTruth$methRange)

## ----methTruth-cor----------------------------------------------------------------------
cor(methTruth$methRange)

## ----methTruth-ind----------------------------------------------------------------------
head(which(methTruth$methDiffInd))

## ----meth-platforms---------------------------------------------------------------------
list.meth.platforms()

## ----meth-figs, fig.width=12, fig.height=8----------------------------------------------
set.seed(999)
simMeth <- simulateMeth(methTruth,  meth.platform = "methArrays", 
                        nSamps = 5, nMol = 1e6)
plotMeth(simMeth)

## ----meth-summary-----------------------------------------------------------------------
summary(simMeth$meth)

## ----methTruth-Fig-3groups, fig.width=10, fig.height=5----------------------------------
set.seed(999)
methTruth <- simulateMethTruth(nProbes = 2e4, nGroups = 3, 
                               pDiff = c(0.05, 0.10), pUp = c(0.80, 0.80))
plotMethTruth(methTruth)

## ----meth-figs-3groups, fig.width=12, fig.height=8--------------------------------------
set.seed(999)
simMeth <- simulateMeth(methTruth,  meth.platform = "methArrays", 
                        nSamps = 5, nMol = 1e6)
plotMeth(simMeth)

## ----getMethylSet-----------------------------------------------------------------------
mset <- getMethylSet(simMeth)
class(mset)
head(minfi::getBeta(mset))

## ----getManifest, eval=FALSE------------------------------------------------------------
#  getManifest(mset)
#  preprocessMethod(mset)

## ----simMeth-figs2, fig.width=12, fig.height=8------------------------------------------
set.seed(999)
siga = sigb = 0.1 * diag(10)
sigOpt = 1 * diag(10)

methTruth <- simulateMethTruth(nProbes = 2e4, nGroups = 2, 
                               pDiff = 0.05, pUp = 0.80)
simMeth <- simulateMeth(methTruth,  meth.platform = "methArrays", 
                        nSamps = 5, nMol = 1e6, 
                        siga = siga, sigb = sigb, sigOpt = sigOpt)
plotMeth(simMeth)

## ----simMeth-figs3, fig.width=12, fig.height=8------------------------------------------
set.seed(999)
siga = sigb = 1 * diag(10)
sigOpt = 2 * diag(10)
simMeth <- simulateMeth(methTruth,  meth.platform = "methArrays", 
                        nSamps = 5, nMol = 1e6, 
                        siga = siga, sigb = sigb, sigOpt = sigOpt)
plotMeth(simMeth)

## ----geneTruth-Fig, fig.width=10, fig.height=5------------------------------------------
set.seed(999)
geneTruth <- simulateGExTruth(nGenes = 2e4, nGroups = 2,  
                              pDiff = 0.05, foldDiff = 5)
plotGExTruth(geneTruth)

## ----geneTruth-summary------------------------------------------------------------------
dim(geneTruth$geneRange)

## ----geneTruth-cor----------------------------------------------------------------------
cor(geneTruth$geneRange)

## ----geneTruth-ind----------------------------------------------------------------------
head(which(geneTruth$genesDiffInd))

## ----gene-platforms---------------------------------------------------------------------
list.GEx.platforms()

## ----gene-figs, fig.width=12, fig.height=6----------------------------------------------
set.seed(999)
sim <- simulateGEx(geneTruth,  GEx.platform = "GExArrays", nSamps = 5)
plotGEx(sim)

## ----gene-summary-----------------------------------------------------------------------
summary(simMeth$meth)

## ----geneTruth-Fig-3groups, fig.width=10, fig.height=5----------------------------------
set.seed(999)
geneTruth <- simulateGExTruth(nGenes = 2e4, nGroups = 3,  
                              pDiff = c(0.05, 0.10), foldDiff = c(5,5))
plotGExTruth(geneTruth)

## ----gene-figs-3groups, fig.width=12, fig.height=6--------------------------------------
set.seed(999)
sim <- simulateGEx(geneTruth,  GEx.platform = "GExArrays", nSamps = 5)
plotGEx(sim)

## ----simGene-figs2, fig.width=12, fig.height=6------------------------------------------
set.seed(999)
siga = sigb = 0.1 * diag(10)
sigOpt = 0.1 * diag(10)

geneTruth <- simulateGExTruth(nGenes = 2e4, nGroups = 2,  
                              pDiff = 0.05, foldDiff = 5)
sim <- simulateGEx(geneTruth,  GEx.platform = "GExArrays", nSamps = 5, 
                   siga = siga, sigb = sigb, sigOpt = sigOpt)
plotGEx(sim)

## ----simGene-figs3, fig.width=12, fig.height=6------------------------------------------
set.seed(999)
siga = sigb = 1 * diag(10)
sigOpt = 1 * diag(10)

geneTruth <- simulateGExTruth(nGenes = 2e4, nGroups = 2,  
                              pDiff = 0.05, foldDiff = 5)
sim <- simulateGEx(geneTruth,  GEx.platform = "GExArrays", nSamps = 5, 
                   siga = siga, sigb = sigb, sigOpt = sigOpt)
plotGEx(sim)

## ----help,eval=FALSE--------------------------------------------------------------------
#  help(package = 'quantroSim', help_type = 'html')

## ----sessionInfo,results ='markup'------------------------------------------------------
sessionInfo()

